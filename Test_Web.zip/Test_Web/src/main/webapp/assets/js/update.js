function updateContent(){
	header.innerHTML='<h2>HOANG<h2>';
	content.innerHTML='<h1>Hoang>'
}