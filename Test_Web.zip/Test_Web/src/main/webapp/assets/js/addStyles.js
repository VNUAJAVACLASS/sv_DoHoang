function addStyles() {
        // Thêm style cho header
        header.style.backgroundColor = '#4CAF50';
        header.style.color = 'white';
        header.style.padding = '20px';
        header.style.textAlign = 'center';
        
        // Thêm style cho nav
        nav.style.backgroundColor = '#333';
        nav.style.padding = '10px';
        
        // Style cho nav links
        allNavLinks.forEach((link, index) => {
            link.style.color = 'white';
            link.style.textDecoration = 'none';
            link.style.padding = '10px 15px';
            link.style.marginRight = '10px';
            link.style.borderRadius = '5px';
            link.style.transition = 'background-color 0.3s';
            
            // Thêm hover effect
            link.addEventListener('mouseenter', function() {
                this.style.backgroundColor = '#555';
            });
            
            link.addEventListener('mouseleave', function() {
                this.style.backgroundColor = 'transparent';
            });
        });
        
        // Style cho sidebar
        sidebar.style.backgroundColor = '#f4f4f4';
        sidebar.style.padding = '15px';
        sidebar.style.borderRadius = '5px';
        
        // Style cho content
        content.style.backgroundColor = 'white';
        content.style.padding = '20px';
        content.style.margin = '10px';
        content.style.borderRadius = '5px';
        content.style.boxShadow = '0 2px 5px rgba(0,0,0,0.1)';
        
        // Style cho footer
        footer.style.backgroundColor = '#333';
        footer.style.color = 'white';
        footer.style.textAlign = 'center';
        footer.style.padding = '15px';
    }