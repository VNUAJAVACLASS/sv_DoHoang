package model;

import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.jsp.el.ELException;

import bean.News;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class NewDAO {
	private String jdbcURL="jdbc:mysql://localhost:3306/dohoang";
	private String jdbcUsername="root";
	private String jdbcPassWord="123";
	private Connection jdbcConnection;
	private Statement statement;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;

	public NewDAO(String jdbcURL,String jdbcUsername,String jdbcPassWord) {
		this.jdbcURL=jdbcURL;
		this.jdbcUsername=jdbcUsername;
		this.jdbcPassWord=jdbcPassWord;
	}
	
	private Connection getConnection() throws Exception {
	    if (jdbcConnection == null || jdbcConnection.isClosed()) {
	        Class.forName("com.mysql.cj.jdbc.Driver"); 
	        jdbcConnection = java.sql.DriverManager.getConnection(
	                jdbcURL, jdbcUsername, jdbcPassWord);
	    }
	    return jdbcConnection;
	}

	
	public News getNewsById(int id) throws Exception {
	    String sql = "SELECT * FROM news WHERE id = ?";

	    preparedStatement = jdbcConnection.prepareStatement(sql);
	    preparedStatement.setInt(1, id);

	    resultSet = preparedStatement.executeQuery();

	    News news = null;
	    if (resultSet.next()) {
	        String title = resultSet.getString("title");
	        String content = resultSet.getString("content");
	        news = new News(id, title, content);
	    }

	  
	    return news;
	}
	
	

	public List<News> getAllNews() throws Exception {
	    List<News> list = new ArrayList<>();

	    String sql = "SELECT * FROM news";

	    statement = jdbcConnection.createStatement();
	    resultSet = statement.executeQuery(sql);

	    while (resultSet.next()) {
	        int id = resultSet.getInt("id");
	        String title = resultSet.getString("title");
	        String content = resultSet.getString("content");

	        News news = new News(id, title, content);
	        list.add(news);
	    }
	    return list;
	}
	
	public boolean deleteNews(int id) throws Exception {
		String sql="DELETE FROM news WHERE id=?";
		
		preparedStatement=jdbcConnection.prepareStatement(sql);
		preparedStatement.setInt(1,id);
		
		boolean delete =preparedStatement.executeUpdate()>0;
		return delete;
	}
	
	public boolean updateNews(News news) throws Exception{
		String sql="UPDATE news SET title = ?, content = ? WHERE id = ?";
		preparedStatement=jdbcConnection.prepareStatement(sql);
		preparedStatement.setString(1, news.getTitle());
		preparedStatement.setString(2, news.getContent());
		preparedStatement.setInt(3, news.getId());

		
		boolean update=preparedStatement.executeUpdate()>0;
		return update;
	}
	
	public void insertNews(News news) {
	    String sql = "INSERT INTO news (title, content) VALUES (?, ?)";
	    try (Connection con = getConnection();
	         PreparedStatement stmt = con.prepareStatement(sql)) {
	        stmt.setString(1, news.getTitle());
	        stmt.setString(2, news.getContent());
	        stmt.executeUpdate();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}



}
