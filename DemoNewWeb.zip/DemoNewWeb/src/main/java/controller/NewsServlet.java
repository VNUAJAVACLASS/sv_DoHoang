

package controller;

import model.NewDAO;
import bean.News;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/news")
public class NewsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private NewDAO newsDAO;

    public void init() {
        // Khởi tạo DAO (kết nối DB)
        String jdbcURL = "jdbc:mysql://localhost:3306/dohoang";
        String jdbcUsername = "root";
        String jdbcPassword = "123";
        newsDAO = new NewDAO(jdbcURL, jdbcUsername, jdbcPassword);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "list";

        try {
            switch (action) {
                case "new":
                    showNewForm(request, response);
                    break;
                case "insert":
                    insertNews(request, response);
                    break;
                case "delete":
                    deleteNews(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "update":
                    updateNews(request, response);
                    break;
                default:
                    listNews(request, response);
                    break;
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    private void listNews(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        List<News> listNews = newsDAO.getAllNews();
        request.setAttribute("listNews", listNews);
        request.getRequestDispatcher("view/list.jsp").forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("view/form.jsp").forward(request, response);
    }

    private void insertNews(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        String title = request.getParameter("title");
        String content = request.getParameter("content");

        News newNews = new News();
        newNews.setTitle(title);
        newNews.setContent(content);

        newsDAO.insertNews(newNews);
        response.sendRedirect("news");
    }

    private void deleteNews(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        int id = Integer.parseInt(request.getParameter("id"));
        newsDAO.deleteNews(id);
        response.sendRedirect("news");
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        int id = Integer.parseInt(request.getParameter("id"));
        News existingNews = newsDAO.getNewsById(id);
        request.setAttribute("news", existingNews);
        request.getRequestDispatcher("view/form.jsp").forward(request, response);
    }

    private void updateNews(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        int id = Integer.parseInt(request.getParameter("id"));
        String title = request.getParameter("title");
        String content = request.getParameter("content");

        News news = new News(id, title, content);
        newsDAO.updateNews(news);
        response.sendRedirect("news");
    }
}

